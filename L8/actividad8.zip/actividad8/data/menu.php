<?php
/* ***********************************
    ACTIVIDAD LECCION 7
    MIGUEL A. CORREA AVILA
 *********************************** */

ini_set("display_errors", "1");
error_reporting(E_ALL);

// Ítems del menú principal
$menu = ["Servicios", "Sobre nosotros", "Contacto"];

?>